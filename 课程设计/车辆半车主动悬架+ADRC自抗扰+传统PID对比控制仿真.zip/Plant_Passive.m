function [sys,x0,str,ts,simStateCompliance] = Plant_Passive(t,x,u,flag)

switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = zeros(4,1);
str = [];
ts  = [0 0];

simStateCompliance = 'UnknownSimState';

function sys=mdlDerivatives(t,x,u)
% ms = 345;mu = 40.5;ks = 17000;kt = 192000;cs = 1500;
ms = 282;mu = 45;ks = 17900;ku = 165790;cs = 1000;
xs = x(1);dxs = x(2);xu = x(3);dxu = x(4);
xr = u;
ddxs = -(cs*(dxs-dxu)+ks*(xs-xu))/ms;
ddxu = (cs*(dxs-dxu)+ks*(xs-xu)-ku*(xu-xr))/mu;
sys = [dxs;ddxs;dxu;ddxu];

function sys=mdlUpdate(t,x,u)

sys = [];

function sys=mdlOutputs(t,x,u)
ms = 282;mu = 45;ks = 17900;ku = 165790;cs = 1000;
xs = x(1);dxs = x(2);xu = x(3);dxu = x(4);
xr = u;
ddxs = -(cs*(dxs-dxu)+ks*(xs-xu))/ms;
ddxu = (cs*(dxs-dxu)+ks*(xs-xu)-ku*(xu-xr))/mu;
sys = [ddxs;xs-xu;xu-xr];

function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlTerminate(t,x,u)

sys = [];
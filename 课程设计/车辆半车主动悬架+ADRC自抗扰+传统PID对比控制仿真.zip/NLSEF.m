function [sys,x0,str,ts,simStateCompliance] = NLSEF(t,x,u,flag)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 11;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];

simStateCompliance = 'UnknownSimState';

function sys=mdlDerivatives(t,x,u)

sys = [];
function sys=mdlUpdate(t,x,u)

sys = [];

function sys=mdlOutputs(t,x,u)
ms = 282;mu = 45;ks = 17900;ku = 165790;cs = 1000;
xshat = u(1);dxshat = u(2);ddxshat = u(7);
%����������
ehat = xshat;dehat = dxshat;ddehat = ddxshat;
%���������PID
alpha1 = 0.5;alpha2 = 1;%0<��1<1<��2
h = 0.001;%����ʱ��
delta = 2*h;%��������С�Ľ��ޣ�Ҳ���������䳤��0.01~0.1
if abs(ehat) <= delta
    fal1 = ehat/(delta^(alpha1-1));
else
    fal1 = ((abs(ehat))^alpha1)*sign(ehat);
end
if abs(dehat) <= delta
    fal2 = dehat/(delta^(alpha2-1));
else
    fal2 = ((abs(dehat))^alpha2)*sign(dehat);
end
if abs(ddehat) <= delta
    fal3 = ddehat/(delta^(alpha2-1));
else
    fal3 = ((abs(ddehat))^alpha2)*sign(ddehat);
end
kp = 500;%����
ki = 5000;%����
kd = 200;%΢��
beta1 = kp;beta2 = ki;beta3 = kd;
%     ut = beta1*fal1+beta2*fal2;
ut = beta1*fal1+beta2*fal2+beta3*fal3;

sys = ut;

function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlTerminate(t,x,u)

sys = [];